// Generated deadlines for the test workload
// This file has to be included only in main_week4.c
long long workloadDeadlines[] = {
	200000,
	600000,
	300000,
	500000,
	400000,
	400000,
	200000,
	150000,
};
